function updateButtonColor(buttonSelector) {
	let buttonBgColor = $(buttonSelector).css("background-color");

	if (tinycolor(buttonBgColor).isLight()) {
		$(buttonSelector).css({ color: "#333" });
	} else {
		$(buttonSelector).css({ color: "#fff" });
	}
}

function btnColor22() {
	updateButtonColor(".button");
}

function aabtnColorTwo() {
	let btnColor = $(".button-two").css("background-color");

	if (tinycolor(btnColor).isLight()) {
		$(".button-two").css({ color: "#333" });
	} else {
		$(".button-two").css({ color: "#fff" });
	}
}

function contentBlock() {
	let btnColor = $(".dascontentBlock").css("background-color");

	if (tinycolor(btnColor).isLight()) {
		$(".dascontentBlock").css({ color: "#333" });
	} else {
		$(".dascontentBlock").css({ color: "#fff" });
	}
}

if ($(".notes-block-wrap").hasClass("flex-column")) {
	$(".notes-block-wrap").css({ gap: "0px" });
}

btnColor22();
aabtnColorTwo();
contentBlock();
